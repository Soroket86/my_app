#!/bin/bash
echo "Запуск бота..."
python bot.py